data = "Hallo das ist nur ein test"
new = ""

for each in data:
    new += each

